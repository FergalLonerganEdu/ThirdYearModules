

  struct ComplexNumber

  {

    double realVal;

    double imaginaryVal;

  };

  void constructComplex(double real, double imaginary);

  void printComplex(ComplexNumber myComplex);

  void multiplyComplex(ComplexNumber first,  ComplexNumber second);

  void divideComplex(ComplexNumber first, ComplexNumber second);
