#ifndef FUNCTIONS_H
#define FUNCTIONS_H


class Functions
{
    public:
        Functions();
        virtual ~Functions();
    protected:
    private:
};

#endif // FUNCTIONS_H
