

  struct ComplexNumber

  {

    double realVal;

    double imaginaryVal;

  };

  ComplexNumber constructComplex(double real, double imaginary);

  void printComplex(ComplexNumber myComplex);

  ComplexNumber multiplyComplex(ComplexNumber first,  ComplexNumber second);

  ComplexNumber divideComplex(ComplexNumber first, ComplexNumber second);
