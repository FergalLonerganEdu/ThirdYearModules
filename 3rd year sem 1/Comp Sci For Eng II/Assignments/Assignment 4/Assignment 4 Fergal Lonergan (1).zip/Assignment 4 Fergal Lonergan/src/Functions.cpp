#include "Functions.h"

Functions::Functions()
{
    //ctor
}

Functions::~Functions()
{
    //dtor
}
