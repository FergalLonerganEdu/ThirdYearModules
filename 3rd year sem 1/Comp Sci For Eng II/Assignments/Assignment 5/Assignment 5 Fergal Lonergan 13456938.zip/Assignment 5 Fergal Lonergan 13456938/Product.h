/*
defining our constructor for Product and the variables and methods used in Product.cpp
*/

class Product
{
private:
    double ProductVolume;
public:
    Product (double vol_entered);
    Product ();
    double product_vol();
};
